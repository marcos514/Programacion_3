<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

/*
¡La primera línea es la más importante! A su vez en el modo de 
desarrollo para obtener información sobre los errores
 (sin él, Slim por lo menos registrar los errores por lo que si está utilizando
  el construido en PHP webserver, entonces usted verá en la salida de la consola 
  que es útil).

  La segunda línea permite al servidor web establecer el encabezado Content-Length, 
  lo que hace que Slim se comporte de manera más predecible.
*/

//*********************************************************************************************//
//INICIALIZO EL APIREST
//*********************************************************************************************//

$app = new Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("GET => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->post('[/]', function (Request $request, Response $response) {   
    $response->getBody()->write("POST => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->put('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("PUT => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->delete('[/]', function (Request $request, Response $response) {   
    $response->getBody()->write("DELETE => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->get('/param/{valor}', function (Request $request, Response $response,$args) {
    $valor=$args["valor"]; 
    $response->getBody()->write("GET => Bienvenido!!! a SlimFramework ".$valor);
    return $response;

});
$app->get('/param/{Edad}/[{Nombre}]', function (Request $request, Response $response,$args) 
{
    $edad=$args["Edad"];
    if(isset($args["Nombre"]))
    {
        $nombre=$args["Nombre"];
        $response->getBody()->write("Nombre: $nombre -- ");
    }
        $response->getBody()->write("Edad: $edad");

    
    return $response;

});


$app->any("/todos/",function (Request $request, Response $response){
    $response->getBody()->write("Mensaje por: ".$request->getMethod());
    return $response;

});

$app->map(["GET","POST"],"/mapa/{valor}",function (Request $request, Response $response,$args){
    var_dump($args);
    $response->getBody()->write("Mensaje por: ".$request->getMethod().$args["valor"]);
    return $response;

});


$app->group("/grupo",function(){
    $this->put("/{mensaje}",function (Request $request, Response $response,$args){
        $response->getBody()->write($args["mensaje"]);
        return $response;

    });
    $this->map(["GET","POST"],"/[{valor}]",function (Request $request, Response $response,$args){
        if(isset($args["valor"]))
        $response->getBody()->write("Otro -->  ".$args["valor"]);
        else
        $response->getBody()->write("Otro sin parametros");
        return $response;
    
    });


});

$app->any("/romper/{valor}",function (Request $request, Response $response,$args){
    $response->getBody()->write("<center><table>");
    for($i=0;$i<100;$i++)
    {
        $response->getBody()->write("<tr><td>".$args["valor"].$i."</td></tr>");
    }
    $response->getBody()->write("</table></center>");
    
    return $response;

});


$app->run();









?>