<?php
include_once "Usuarios.php";
class MW
{
    public function ComprobarSeteo($request, $response, $next)
    {
        $mail=isset($_POST["mail"]);
        $clave=isset($_POST["clave"]);
        if($mail && $clave)
        {
            return $next($request,$response);
        }
        else if($mail==$clave)
        {
            return $response->withJson("Ningun campo ingresado",200);
        }
        else if( !$mail)
        {
            return $response->withJson("Mail no ingresado",200);
        }        
        else if( !$clave)
        {
            return $response->withJson("Clve no ingresada",200);
        }

    }

    public static function ComprobarValor($request, $response, $next)
    {
        $mail=$_POST["mail"]!="";
        $clave=$_POST["clave"]!="";
        if($mail && $clave)
        {
            return $next($request,$response);
        }
        else if($mail==$clave)
        {
            return $response->withJson("Campos vacios",200);
        }
        else if( !$mail)
        {
            return $response->withJson("Mail vacio",200);
        }        
        else if( !$clave)
        {
            return $response->withJson("Clave vacia",200);
        }

    }

    public static function ComprobarBD($request, $response, $next)
    {

        $mail=$_POST["mail"];
        $clave=$_POST["clave"];
        $usuario=new Usuario("","","",$mail,"",$clave);
        $mailVer=!(Usuario::TraerMail($mail)>0);
        $claveVer=!(Usuario::TraerClave($clave)>0);
        if($usuario->TraerEste()>0)
        {
            return $next($request,$response);
        }
        else if($mailVer&&$claveVer)
        {
            return $response->withJson("No existe ninguno",200);
        }
        else if($mailVer)
        {
            return $response->withJson("Mail No encontrado",200);
        }        
        else
        {
            return $response->withJson("Usuario no valido",200);
        }

    }
}




?>