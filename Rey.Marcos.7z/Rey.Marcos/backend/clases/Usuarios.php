<?php
class Usuario
{
    public $mail;
    public $nombre;
    public $apellido;
    public $clave;
    public $perfil;
    public $id;
    public $foto;
    public function __construct($id="",$nombre="",$apellido="",$email="",$foto="",$clave="",$perfil="")
    {
        $this->apellido=$apellido;
        $this->perfil=$perfil;
        $this->mail=$email;
        $this->nombre=$nombre;
        $this->clave=$clave;
        $this->foto=$foto;
        $this->id=$id;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios (nombre,apellido,correo,foto,clave,perfil)values(:nombre,:apellido,:mail,:foto,:clave,:perfil)");
        $consulta->bindValue(':mail',$this->mail, PDO::PARAM_STR);
        $consulta->bindValue(':apellido',$this->apellido, PDO::PARAM_STR);
        $consulta->bindValue(':perfil',$this->perfil, PDO::PARAM_STR);
        $consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':clave',$this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':foto',$this->foto, PDO::PARAM_STR);

        		
        return $consulta->execute();
    }

    public static function TraerTodo()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios");
			$consulta->execute();			
			return $consulta->fetchAll();		
    }
    
    public function TraerEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where correo='".$this->mail."' and clave='".$this->clave."'");
            $consulta->execute();
			return $consulta->fetch();
    }
    
    public static function TraerMail($mail)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where correo='".$mail."'");
            $consulta->execute();
			return $consulta->fetch();
    }
    
    public static function TraerClave($clave)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where clave='".$clave."'");
            $consulta->execute();
			return $consulta->fetch();
	}

}





?>