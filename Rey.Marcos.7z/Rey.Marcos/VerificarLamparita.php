<?php
include "clases/Lamparita.php";
$color=isset($_GET["color"])? $_GET["color"]:false;
$tipo=isset($_GET["tipo"])? $_GET["tipo"]:false;

$todas=Lamparita::TraerTodo();
$comprobadorColor=true;
$comprobadorTipo=true;
$lamparita;
$comp=false;
foreach ($todas as $lampara) 
{
    $var=Lamparita::Comparar($lampara,$color,$tipo);

    if($var==3)
    {
        $comp=true;
        $lamparita=$lampara;
        break;
    }
    else if($var==2)
    {
        $comprobadorTipo=false;
    }
    else if($var==1)
    {
        $comprobadorColor=false;
    }
    
}


if($comp)
{
    echo $lamparita->ToString();
    echo "Precio Con Iva: ".$lamparita->PrecioConIva();
}
else
{
    if($comprobadorColor && $comprobadorTipo)
    {
        echo "no coincide nada";
    }
    else if($comprobadorColor)
    {
        echo "no coincide el tipo";
    }
    else
    {
        echo "no coincide el color";
    }
}

