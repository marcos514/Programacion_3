<?php
include "clases/Lamparita.php";
$todas=Lamparita::TraerTodo();
$archivo=fopen("archivos/listado.txt","w");
foreach ($todas as $key ) {
    echo $key->AJson()."<br>";
    fwrite($archivo, $key->AJson()."\n");
}




?>