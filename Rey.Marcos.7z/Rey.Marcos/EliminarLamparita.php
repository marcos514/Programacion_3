<?php
include "clases/Lamparita.php";
if(isset($_GET["tipo"]))
{
    $todas=Lamparita::TraerTodo();
    $tipo=$_GET["tipo"];
    $color="";
    foreach ($todas as $key )
    {
        $var=Lamparita::Comparar($lampara,$color,$tipo);
        if($var==2)
        {
            echo "Encontro la lamparita";
            break;
        }

    }
}/*
else if(isset($_POST["accion"]))
{
    if($_POST["accion"]=="borrar")
    {
        $tipo=isset($_POST["tipo"])? $_POST["tipo"]:false;

        $lamparita=new Lamparita("a");
        $lamparita->Eliminar();


        $archivo=fopen("archivos/listado.txt","r");
        while (!feof($archivo)) 
        {
            $linea=trim(fgets($archivo));
            if($linea!="")
            {
                $json=json_decode($linea);
                $hora=explode(".",$json->path);
                move_uploaded_file($json->path,"lamparitasBorradas/".$tipo.".borrado.".$hora[2]);
                unlink($json->path);
            }
        }
    }
}*/




?>