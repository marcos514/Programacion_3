<?php
include "clases/Lamparita.php";
$precio=isset($_POST["precio"])? $_POST["precio"]:false;
$color=isset($_POST["color"])? $_POST["color"]:false;
$tipo=isset($_POST["tipo"])? $_POST["tipo"]:false;
$hora=date("omGis");
$lamparita=new Lamparita($tipo,$precio,$color);
$lamparita->Agregar();
$archivo=fopen("archivos/lamparita_sin_foto.txt","a");
fwrite($archivo,$hora." - ".$lamparita->ToString()."\n");





?>