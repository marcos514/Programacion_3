<?php
interface IVendible
{
    function PrecioConIva();
}



?>