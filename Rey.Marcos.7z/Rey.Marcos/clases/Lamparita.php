<?php
include "IVendible.php";
class Lamparita implements IVendible
{
    public $tipo;
    public $precio;
    public $color;
    public $path;
    

    public function __construct($tipos="",$precios=15,$colores="blanco",$paths=".jpg")
    {
        $this->tipo=$tipos;
        $this->color=$colores;
        $this->precio=$precios;
        $this->path=$paths;
    }

    public function AJson()
    {
        return "{'tipo':'".$this->tipo."','color':'".$this->color."','precio':".$this->precio.",'path':'".$this->path."'}";
    }

    public static function Comparar($lampara,$color,$tipo)
    {
        if(trim($lampara->color)==trim($color) && trim($lampara->tipo)==trim($tipo))
        {
            return 3;
        }
        else if($lampara->color==$color)
        {
            return 2;
        }
        else if($lampara->tipo==$tipo)
        {
            return 1;
        }

        return 0;
    }

    public function PrecioConIva()
    {
        return $this->precio*1.33;
    }


    public function ToString()
    {
        return $this->tipo." - ".$this->precio." - ".$this->color." - ".$this->path;
    }

    public function Agregar()
    {
        try
        {
            $PDO=new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', "root", "");
        }
        catch (PDOException $e) 
        {
            print "Error!!!<br/>" . $e->getMessage();
            die();
        }
        $consulta=$PDO->prepare("INSERT INTO lamparitas(color, precio, path, tipo) VALUES (:color,:precio,:path,:tipo)");
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
        $consulta->bindValue(':tipo',$this->tipo, PDO::PARAM_STR);
        $consulta->bindValue(':path', $this->path, PDO::PARAM_STR); 
        $consulta->execute();
    }

    public static function TraerTodo()
    {
        try
        {
            $PDO=new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', "root", "");
        }
        catch (PDOException $e) 
        {
            print "Error!!!<br/>" . $e->getMessage();
            die();
        }

        $consulta=$PDO->prepare("SELECT * from lamparitas");
        $consulta->execute();
        $consulta->setFetchMode(PDO::FETCH_INTO, new Lamparita);
        return $consulta;
    }

    public function Eliminar()
    {
        try
        {
            $PDO=new PDO('mysql:host=localhost;dbname=lamparitas_bd;charset=utf8', "root", "");
        }
        catch (PDOException $e) 
        {
            print "Error!!!<br/>" . $e->getMessage();
            die();
        }
        $consulta=$PDO->prepare("DELETE FROM lamparitas WHERE tipo = ".$this->tipo);  
        $consulta->execute();
    }
    
}





?>