<?php
include "clases/Lamparita.php";
$precio=isset($_POST["precio"])? $_POST["precio"]:false;
$color=isset($_POST["color"])? $_POST["color"]:false;
$tipo=isset($_POST["tipo"])? $_POST["tipo"]:false;
$extencion=pathinfo($_FILES["img"]["name"],PATHINFO_EXTENSION);

$imagen="lamparitas/imagenes/".trim($tipo).".".$color.".".date("Gis").".".$extencion;

$lamparita=new Lamparita($tipo,$precio,$color,$imagen);
$lamparita->Agregar();
$tmp_name=$_FILES["img"]["tmp_name"];
move_uploaded_file($tmp_name,$imagen);
header("Location: ./Listado.php");





?>