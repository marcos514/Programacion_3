<?php

interface IMiddleWare{
    static function VerificarUsuario($request, $response, $next);
}