<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";

use Firebase\JWT\JWT as JWT;


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);

$app->group('/test', function () {

    $this->post('[/]', function ($request, $response) {      
        $parse=$request->getParsedBody();
        $clave=$parse["clave"];
        $usuario=$parse["usuario"];
        $array=array("clave"=>$clave,"usuario"=>$usuario);
        $token=JWT::encode($array,"clave");
        
        return $response->withJson($token,200);
    });
    $this->post('[/]', function ($request, $response) {      
        $parse=$request->getParsedBody();
        $token=$parse["token"];
        
        try
        {
            JWT::encode($array,"clave",["HS256"]);
        }
        catch(Exception $e)
        {
            throw $e;

        }
        
        return $response->withJson($token,200);
    });
     
})/*->add(\Usuario::class. "::AgregarUsuario")*/;

$app->run();

?>