<?php
include_once "AccesoDatos.php";
class Media
{
    public $color;
    public $marca;
    public $talle;
    public $precio;
    public $id;
    public function __construct($color="",$marca="",$precio="",$talle="",$id="")
    {
        $this->color=$color;
        $this->precio=$precio;
        $this->marca=$marca;
        $this->talle=$talle;
        $this->id=$id;
        

    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into medias (color, marca, precio , talle)values(:color, :marca, :precio , :talle)");
        $consulta->bindValue(':precio',$this->precio,  PDO::PARAM_STR);
        $consulta->bindValue(':talle', $this->talle, PDO::PARAM_STR);
        $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
        $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public function Borrar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
		delete 
		from productos 				
		WHERE id=:id");	
        $consulta->bindValue(':id',$this->id, PDO::PARAM_STR);
		$consulta->execute();
		return $consulta->rowCount();
    }

    public function Modificar()
	{

		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("update productos set precio='$this->precio',nombre='$this->nombre'WHERE id=$this->id");
		return $consulta->execute();

    }
    public static function TraerTodo()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from medias");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    
    public function TraerEste()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select  from Productos where nombre='".$this->nombre."'");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}



}







?>