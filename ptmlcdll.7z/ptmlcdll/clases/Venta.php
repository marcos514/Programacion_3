<?php

require_once('AccesoDatos.php');
require_once('Anteojos.php');

class Venta {
    public $id;
    public $id_anteojos;
    public $cantidad;
    public $fecha;

    public function __construct($id = "", $id_anteojos = "", $cantidad = "", $fecha = "") {
        $this->id = $id;
        $this->id_anteojos = $id_anteojos;
        $this->cantidad = $cantidad;
        $this->fecha = $fecha;
    }

    public function toJson() {
        return '{"id":'.$this->id.',"id_anteojos":'.$this->id_anteojos.',"cantidad":'.$this->cantidad.',"fecha":"'.$this->fecha.'"}';
    }

    public static function cargarVenta($request, $response) {
        $arrayDeParametros = $request->getParsedBody();
        $id_anteojos = $arrayDeParametros["id_anteojos"];
        $cantidad = $arrayDeParametros["cantidad"];
        $fecha = $arrayDeParametros["fecha"];
    
        $venta = new Venta("", $id_anteojos, $cantidad, $fecha);
        $respuesta = $venta->Agregar();
    
        if ($respuesta) {
            $json = '{ "status" : "Registro insertado exitosamente" }';
            $codigo = 200;
        }
        else {
            $json = '{ "status" : "Error, no se pudo ingresar el registro en la base de datos" }';
            $codigo = 409;
        }
            
        return $response->withJson(json_decode($json), $codigo);
    }

    public static function traerVentas($request, $response) {
        $ventas = Venta::TraerTodoObj();
        $anteojos = Anteojos::TraerTodoObj();
        $propietario = $request->getAttribute('propietario');
        $empleado = $request->getAttribute('empleado');
        $encargado = $request->getAttribute('encargado');
        $fecha = ($request->getHeader("fecha")[0]);
        $total = 0;
    
        $str = "[ ";
    
        foreach ($ventas as $venta)  {
            if($str != "[ ")
                $str .= ", ";
    
            if ($propietario && $fecha != NULL) {
                if ($venta->fecha == $fecha)
                    $str .= $venta->toJson();
            }
            else 
                $str .= $venta->toJson();

            if ($empleado || $encargado) {
                foreach ($anteojos as $anteojo) {
                    if ($venta->id_anteojos == $anteojo->id) {
                        $total += ($anteojo->precio * $venta->cantidad);
                        break;
                    }
                }
            }
        }

        if ($empleado || $encargado) {
            if($str != "[ ")
                $str .= ", ";

            $str .= '{ "Monto total de ventas" : ' . $total . ' }';
        }
    
        $str.=" ]";
    
        if($str == "[  ]") {
            $str = '{ "status" : "Error" }';
        }
    
        return $response->withJson(json_decode($str), 200);
    }

    public function Agregar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO ventas_anteojos (id_anteojos, cantidad, fecha) VALUES (:id_anteojos, :cantidad, :fecha)");
        $consulta->bindValue(':id_anteojos', $this->id_anteojos, PDO::PARAM_INT);
        $consulta->bindValue(':cantidad', $this->cantidad, PDO::PARAM_INT);
        $consulta->bindValue(':fecha', $this->fecha, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public static function TraerTodoObj() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM ventas_anteojos");
        $consulta->execute();
        $arrayObj = array();
        
        while($fila = $consulta->fetch()){
            $obj = new Venta($fila[0], $fila[1], $fila[2], $fila[3]);
            array_push($arrayObj, $obj);
        }

        return $arrayObj;
    }
}