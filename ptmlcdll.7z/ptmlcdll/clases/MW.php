<?php

require_once('Usuario.php');

use Firebase\JWT\JWT as JWT;

class MW {

    public static function Verificar($request, $response, $next)
    {
        $dni=isset($_POST["dni"]);
        $clave=isset($_POST["clave"]);
        if($dni&&$clave)
        {
            return $next($request,$response);
        }
        return $response->withJson(json_decode('{"mensaje":"Error"}'), 409);
        
    }

    public static function VerificarDni($request, $response, $next)
    {
        $dni=isset($_POST["dni"]);
        if($dni)
        {
            return $next($request,$response);
        }
        return $response->withJson(json_decode('{"mensaje":"Error"}'), 409);

    }

    public static function VerificarToken($request, $response, $next)
    {
        $token=isset($_POST["token"]);
        if($token)
        {
            return $next($request,$response);
        }
        return $response->withJson(json_decode('{"mensaje":"Error"}'), 409);

    }


}