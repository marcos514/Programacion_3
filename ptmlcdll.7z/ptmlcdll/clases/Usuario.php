<?php

require_once('AccesoDatos.php');

use Firebase\JWT\JWT as JWT;

class Usuario {
    public $dni;
    public $clave;
    public $nombre;
    public $puesto;

    public function __construct($dni="",$nombre="",$clave="",$puesto="") {
        $this->clave = $clave;
        $this->nombre = $nombre;
        $this->puesto = $puesto;
        $this->dni = $dni;
    }

    public function toJson() {
        return '{"dni":'.$this->dni.',"puesto":"'.$this->puesto.'","clave":"'.$this->clave.'","nombre":"'.$this->nombre.'"}';
    }

    public static function cargarUsuario($request, $response) {
        $arrayDeParametros = $request->getParsedBody();
        $puesto = $arrayDeParametros["puesto"];
        $clave = $arrayDeParametros["clave"];
        $nombre = $arrayDeParametros["nombre"];
        $dni = $arrayDeParametros["dni"];
        /*$archivos = $request->getUploadedFiles();
    
        $destino = "./fotos/";
        $nombreAnterior = $archivos['foto']->getClientFilename();
        $extension = explode(".", $nombreAnterior);
        $extension = array_reverse($extension);
        $destinoFinal = $destino . $correo . "." . $extension[0];
        $archivos['foto']->moveTo($destinoFinal);*/
    
        $usuario = new Usuario($dni,$nombre,$clave,$puesto);
        $respuesta = $usuario->Agregar();
        $json="";
        $codigo="";
        //var_dump($usuario);
        
        if ($respuesta) {
            $json = '{ "exito" : "true" , "mensaje": "Empleado Agregado","empleado":'.$usuario->toJson().' }';
            $codigo = 200;
        }
            
        else {
            $json = '{ "exito" : false , "mensaje": "Empleado NO Agregado" }';
            $codigo = 409;
        }
            
        return $response->withJson(json_decode($json), $codigo);
    }

    public static function modificarUsuario($request, $response) {

        $dni = ($request->getHeader("dni")[0]);
        $nombre = ($request->getHeader("nombre")[0]);
        $puesto = ($request->getHeader("puesto")[0]);
        $clave = ($request->getHeader("clave")[0]);
        
        /*$archivos = $request->getUploadedFiles();
    
        $destino = "./fotos/";
        $nombreAnterior = $archivos['foto']->getClientFilename();
        $extension = explode(".", $nombreAnterior);
        $extension = array_reverse($extension);
        $destinoFinal = $destino . $correo . "." . $extension[0];
        $archivos['foto']->moveTo($destinoFinal);*/
    
        $usuario = new Usuario($dni,$nombre,$clave,$puesto);

        $respuesta = $usuario->Modificar();
        $json="";
        $codigo="";

        if ($respuesta) {
            $json = '{ "exito" : "true" , "mensaje": "Empleado Modificado","empleado":'.$usuario->toJson().' }';
            $codigo = 200;
        }
            
        else {
            $json = '{ "exito" : false , "mensaje": "Empleado NO Modificado" }';
            $codigo = 409;
        }
        
        return $response->withJson(json_decode($json), $codigo);
    }


    public static function eliminarUsuario($request, $response,$args) {

        $dni = $args["dni"];
        
        /*$archivos = $request->getUploadedFiles();
    
        $destino = "./fotos/";
        $nombreAnterior = $archivos['foto']->getClientFilename();
        $extension = explode(".", $nombreAnterior);
        $extension = array_reverse($extension);
        $destinoFinal = $destino . $correo . "." . $extension[0];
        $archivos['foto']->moveTo($destinoFinal);*/
    
        $usuario = new Usuario($dni);
        $datos=$usuario->TraerEste();
        $usuario=new Usuario($dni,$datos["nombre"],$datos["clave"],$datos["puesto"]);
        $respuesta = $usuario->Borrar();
        $json="";
        $codigo="";

        if ($respuesta) {
            $json = '{ "exito" : "true" , "mensaje": "Empleado Eliminado","empleado":'.$usuario->toJson().' }';
            $codigo = 200;
        }
            
        else {
            $json = '{ "exito" : false , "mensaje": "Empleado NO Eliminar" }';
            $codigo = 409;
        }
        
        return $response->withJson(json_decode($json), $codigo);
    }

    public static function traerUsuarios($request, $response) {
        $usuarios = Usuario::TraerTodoObj();
    
        $str = "[ ";
        foreach ($usuarios as $usuario)  {
            if($str != "[ ")
                $str .= ", ";
    
            $str .= $usuario->toJson();
        }
    
        $str.=" ]";
    
        if($str == "[  ]") {
            $str = '{ "status" : "Error al traer" }';
        }
    
        return $response->withJson(json_decode($str), 200);
    }

    public static function crearToken($request, $response) {
        $arrayDeParametros = $request->getParsedBody();
        $dni = $arrayDeParametros["dni"];
        $clave = $arrayDeParametros["clave"];
    
        try {
            $usuario = new Usuario($dni, "", $clave);
            $respuesta = $usuario->TraerEsteObj();
            $datos=$usuario->TraerEste();
            $usuario=new Usuario($dni,$datos["nombre"],$datos["clave"],$datos["puesto"]);
    
            if($respuesta !== NULL) 
            {
                $payload = array("correo" => $respuesta->correo, "nombre" => $respuesta->nombre, "apellido" => $respuesta->apellido, "perfil" => $respuesta->perfil, "foto" => $respuesta->foto, "exp" => (time() + 20), "iat" => time());
                $token = JWT::encode($payload, "1235");
                return $response->withJson($token, 200);
            }
    
            $json = '{ "valido" : false }';
            return $response->withJson(json_decode($json), 200);
        }
        catch(Exception $e) {
            throw $e;
        }
    }

    public static function verificarToken($request, $response) {
        $token = ($request->getHeader("token")[0]);
    
        try {
            $todo = JWT::decode($token, "1235", ["HS256"]);
            $json = '{ "status" : "Válido" }';
            return $response->withJson(json_decode($json), 200);
        }
        catch(Exception $e) {
            $json = '{ "status" : "Error" }';
            return $response->withJson(json_decode($json), 409);
        }
    }

    public function Agregar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (puesto, clave, nombre, dni) VALUES (:puesto, :clave, :nombre, :dni)");
        $consulta->bindValue(':puesto',$this->puesto, PDO::PARAM_STR);
        $consulta->bindValue(':clave',$this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':dni',$this->dni, PDO::PARAM_INT);
        		
        return $consulta->execute();
    }

    public function Borrar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta = $objetoAccesoDato->RetornarConsulta("DELETE FROM usuarios WHERE dni = :dni"); 
        $consulta->bindValue(':dni', $this->dni, PDO::PARAM_STR);
        $consulta->execute();
        
		return $consulta->rowCount();
    }

    public function Modificar() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE usuarios SET puesto=:puesto, clave=:clave, nombre=:nombre WHERE dni =".$this->dni);
        $consulta->bindValue(':puesto',$this->puesto, PDO::PARAM_STR);
        $consulta->bindValue(':clave',$this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public function TraerEste() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE dni = :dni");
        $consulta->bindValue(':dni',$this->dni, PDO::PARAM_STR);
        $consulta->execute();

        return $consulta->fetch(PDO::FETCH_ASSOC);
    }

    

    public function TraerEsteObj() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE correo = :correo");
        $consulta->bindValue(':correo',$this->correo, PDO::PARAM_STR);
        $consulta->execute();
        $obj = NULL;

        while($fila = $consulta->fetch()){
            $obj = new Usuario($fila[0], $fila[1], $fila[2], $fila[3], $fila[4], $fila[5], $fila[6]);
        }

        return $obj;
    }

    public static function TraerTodo() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios");
        $consulta->execute();

        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function TraerTodoObj() {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios");
        $consulta->execute();
        $arrayObj = array();
        while($fila = $consulta->fetch()){
            
            $obj = new Usuario($fila["dni"], $fila["nombre"], $fila["clave"], $fila["puesto"]);
            array_push($arrayObj, $obj);
        }

        return $arrayObj;
    }
}