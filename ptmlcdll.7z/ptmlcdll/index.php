<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";
require_once "./clases/Usuario.php";
require_once "./clases/MW.php";
require_once "./clases/Anteojos.php";
require_once "./clases/Venta.php";

use Firebase\JWT\JWT as JWT;




$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);

//$app->post('[/]', \Anteojos::class . '::cargarAnteojos');
$app->post('[/]', \Usuario::class . '::cargarUsuario')->add(\MW::class."::VerificarDni");
$app->put('[/]', \Usuario::class . '::modificarUsuario');
$app->delete('/{dni}', \Usuario::class . '::eliminarUsuario');
$app->get('[/]', \Usuario::class . '::traerUsuarios');


$app->post('/login', function($request, $response){
    $arrayDeParametros = $request->getParsedBody();
        $dni = $arrayDeParametros["dni"];
        $clave = $arrayDeParametros["clave"];
    
        try {
            $usuario = new Usuario($dni, "", $clave);
            $respuesta = $usuario->TraerEsteObj();
            $datos=$usuario->TraerEste();
            $usuario=new Usuario($dni,$datos["nombre"],$datos["clave"],$datos["puesto"]);
            $str='{"exito":"true","mensaje":"Logeado exito","empleado":'.$usuario->toJson();
    
            if($usuario !== NULL) 
            {
                $payload = array("dni" => $usuario->correo, "nombre" => $usuario->nombre, "puesto" => $usuario->puesto);
                $token = JWT::encode($payload, "1235");
                $str.=',"empleadoJWT":"'.$token.'"}';
                return $response->withJson(json_decode($str), 200);
            }
    
            $json = '{ "valido" : false }';
            return $response->withJson(json_decode($json), 200);
        }
        catch(Exception $e) {
            throw $e;
        }
}) ->add(\MW::class . '::Verificar');


$app->run();

?>