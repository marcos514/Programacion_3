<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require "usuario.php";



require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("GET => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->post('[/]', function (Request $request, Response $response) {   
    $response->getBody()->write("POST => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->put('[/]', function (Request $request, Response $response) {  
    $response->getBody()->write("PUT => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->delete('[/]', function (Request $request, Response $response) {  
    $response->getBody()->write("DELETE => Bienvenido!!! a SlimFramework");
    return $response;

});


$funcionNueva=function( $request, $response,$next)
{
    $response->getBody()->write("<br>Esta es la funcion de app antes<br>");
    $response=$next($request,$response);
    $response->getBody()->write("<br>Esta es la funcion de app despues<br>");
    return $response;
};

$app->add($funcionNueva);

$app->put('/params/{nombre}', function (Request $request, Response $response,$args) {  
    $response->getBody()->write("PUT del params ".$args["nombre"]);
    return $response;

})->add(function ($request, $response,$next)
{   
    $response->getBody()->write("<br>Funcion agregada en el put de params Antes<br>");
    $response=$next($request,$response);
    $response->getBody()->write("<br>Funcion agregada en el put de params Despues<br>");
    return $response;
})->add(function ($request, $response,$next)
{   
    $response->getBody()->write("<br>Funcion agregada en el add del put de params  Antes<br>");
    $response=$next($request,$response);
    $response->getBody()->write("<br>Funcion agregada en el add del put put de params Despues<br>");
    return $response;
});


$app->group('/credenciales', function () {

    $this->get('[/]', function ($request, $response, $args) {
        $response->getBody()->write("Estoy en el GET de credenciales");
    });
    $this->post('[/]', function ($request, $response, $args) {      
        $response->getBody()->write("Estoy en el POST de credenciales");
    });
     
})->add(function($request,$response,$next)
{
    if($request->isGet())
    {
        $response->getBody()->write("<br>El request es un GET<br>");
        $response=$next($request,$response);
    }
    else if($request->isPost())
    {
        $arrayPost=$request->getParsedBody();
        if(isset($arrayPost["nombre"])&& isset($arrayPost["perfil"]))
        {
            if($arrayPost["perfil"]=="admin")
            {
                $response->getBody()->write("<br>Bienveido ".$arrayPost["nombre"]."<br>");
                $response=$next($request,$response);
            }
            else
            {
                $response->getBody()->write("<br>NO TENES PERMISO<br>");                
            }
        }
        else
        {
            $response->getBody()->write("<br>Parametros no enviados<br>");
        }
    }
    return $response;
} 
);

$app->group('/grupo/POO', function () {

    $this->get('[/]', function ($request, $response, $args) {
        $response->getBody()->write("Estoy en el GET de credenciales");
    });
    $this->post('[/]', function ($request, $response, $args) {      
        $response->getBody()->write("Estoy en el POST de credenciales");
    });
     
})->add(\Usuario::class. "::AgregarUsuario");






$app->run();