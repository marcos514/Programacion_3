function Saludar()
{
    var nombre=$("#txtNombre").val();
    var perfil=$("#txtPerfil").val();
    var formData=new FormData();
    formData.append("nombre",nombre);
    formData.append("clave",perfil);

    $.ajax({
        type:"POST",
        url:"grupo/POO",
        data:formData, //"nombre="+nombre+"&perfil="+perfil,
        dataType:"text",
        async:true,
        contentType: false,
        processData: false
    })
    .done(function(params) {
        $("#divPost").html(params);          
    })
    .fail(function () {
        $("#divPost").html("error"); 
        
    });
}

function Modificar() 
{
    var nombre=$("#txtNombre").val();
    var mijson=JSON.parse('{"valor":{"nombre":"'+nombre+'"}}');

    $.ajax({
        type:"POST",
        url:"json2.php",
        data:mijson,
        dataType:"json",
        async:true
    })
    .done(function(params) {
        $("#divPost").html("El nombre es: "+params.nombre); 
    })
    .fail(function () {
        $("#divPost").html("error"); 
        
    });
}