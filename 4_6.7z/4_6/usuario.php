<?php
class Usuario
{
    public static function UsuarioValido($request,$response,$next)
    {
        try 
        {
            //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
            $usuario='root';
            $clave='';
            if($request->isPost())
            {
                $arrayPost=$request->getParsedBody();
                $objetoPDO = new PDO('mysql:host=localhost;dbname=marcos;charset=utf8', $usuario, $clave);
                $sentencia=$objetoPDO->Prepare('SELECT nombre FROM usuarios where clave=:clave and nombre=:nombre');
                $sentencia->bindParam(":nombre",$arrayPost["nombre"],PDO::PARAM_STR);            
                $sentencia->bindParam(":clave",$arrayPost["clave"],PDO::PARAM_STR);
                $sentencia->Execute();
                $nombre=$sentencia->fetch();
                if($nombre>0)
                {
                    //$response->getBody().write("Hola".$nombre["nombre"]);
                    $response->getBody()->write("Hola ".$nombre["nombre"]."<br>");
                    return $next($request,$response);
                }
                else
                {
                    $response->getBody()->write("Sin permiso");
                    return $response;
                }
            }
        
        } 
        catch (PDOException $e) 
        {
            echo "Error!!!\n" . $e->getMessage();
        }
    }

    public static function AgregarUsuario($request,$response,$next)
    {
        try 
        {
            //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
            $usuario='root';
            $clave='';
            if($request->isPost())
            {
                $arrayPost=$request->getParsedBody();
                $objetoPDO = new PDO('mysql:host=localhost;dbname=marcos;charset=utf8', $usuario, $clave);
                $sentencia=$objetoPDO->Prepare('INSERT INTO usuarios (nombre,clave) values(:nombre,:clave)');
                $sentencia->bindParam(":nombre",$arrayPost["nombre"],PDO::PARAM_STR);            
                $sentencia->bindParam(":clave",$arrayPost["clave"],PDO::PARAM_STR);
                $sentencia->Execute();
                return $response;
            }
        
        } 
        catch (PDOException $e) 
        {
            echo "Error!!!\n" . $e->getMessage();
        }
    }
}







?>