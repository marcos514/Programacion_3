<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once "./vendor/autoload.php";
include "clases/Verificadora.php";
include_once "clases/cd.php";

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new Slim\App(["settings" => $config]);



$app->get('[/]', function (Request $request, Response $response) {    
    $cd=new cd();
    $todo=cd::TraerTodoLosCds();
    $response=$response->withJson($todo, 200);
    
   return $response;
});

$app->post('[/]', function (Request $request, Response $response) {  
    $cd=new cd();
    $json=$request->getParsedBody();
    $cd->titulo=$json["titulo"];
    $cd->cantante=$json["cantante"];
    $cd->año=$json["año"];
    
    $response->getBody()->write($cd->InsertarElCd());

    
    return $response;
});
$app->put('[/]', function (Request $request, Response $response) {  

    $response->getBody()->write("PUT => Bienvenido!!! a SlimFramework");

    return $response;

});

$app->delete('[/]', function (Request $request, Response $response) {  
    $response->getBody()->write("No es admin para eliminar");
    return $response;

    $cd=new cd();
    $json=$request->getParsedBody();
    $nombre=$json["nombre"];
    $clave=$json["clave"];
    $cd->titulo=$json["titulo"];
    $cd->cantante=$json["cantante"];
    $cd->año=$json["año"];
    $response->getBody()->write("Se Va A Eliminar");
    if(Verificadora::VerificarAdmin($nombre,$clave))
    {
        $cant=$cd->BorrarCdCompleto();
        if($cant>0)
        {
            $response->getBody()->write("Se elimino ".$cant."Elementos");
            return $response;
        }
        else
        {
            $response->getBody()->write("No Se elimino ");
            return $response;
        }
    }
    $response->getBody()->write("No es admin para eliminar");
    return $response;


});

$app->add(\Verificadora::class."::VerificarUsuario");

$app->run();

?>
